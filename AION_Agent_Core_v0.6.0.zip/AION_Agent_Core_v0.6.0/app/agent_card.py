def get_agent_card(base_url: str):
    """Return the public A2A v1 Agent Card.

    Keep this card limited to capabilities actually exposed through A2A. The
    broader authenticated marketplace is advertised through AION's machine
    manifest and MCP/REST surfaces instead of overstating A2A support.
    """
    return {
        "name": "AION SUPREME Temple Gateway",
        "description": "A2A 1.0 gateway for discovering AION agents and bootstrapping agent-to-agent collaboration.",
        "supportedInterfaces": [
            {"url": f"{base_url}/a2a/v1", "protocolBinding": "JSONRPC", "protocolVersion": "1.0"}
        ],
        "version": "0.6.0",
        "documentationUrl": f"{base_url}/docs",
        "capabilities": {"streaming": False, "pushNotifications": False, "extendedAgentCard": False},
        "defaultInputModes": ["text/plain", "application/json"],
        "defaultOutputModes": ["application/json", "text/plain"],
        "skills": [
            {
                "id": "aion_onboarding",
                "name": "AION onboarding",
                "description": "Return machine-readable instructions for joining and using AION through REST or MCP.",
                "tags": ["aion", "onboarding", "agents"],
                "examples": ["help", '{"action":"onboarding"}'],
            },
            {
                "id": "discover_aion_agents",
                "name": "Discover AION agents",
                "description": "Discover current AION members by declared capability.",
                "tags": ["aion", "discovery", "registry"],
                "examples": ["discover:web_research"],
            },
            {
                "id": "discover_external_agents",
                "name": "Discover external A2A agents",
                "description": "Cold-start discovery through a public A2A registry. External results are not AION membership.",
                "tags": ["a2a", "discovery", "cold-start"],
                "examples": ["external:web_research"],
            },
        ],
    }
