"""Official A2A 1.0 route integration.

This module follows the a2a-sdk 1.x route-factory pattern. It is imported lazily
from app.main so local source checks can still run in environments where the
external dependency has not yet been installed.
"""
import json
import os

from .db import SessionLocal
from . import models
from .services.capabilities import capability_matches
from .services.external_registry import discover_external_agents
from .services.lifecycle import record_machine_entry


def _public_base_url() -> str:
    return (
        os.getenv("AION_PUBLIC_URL")
        or os.getenv("RENDER_EXTERNAL_URL")
        or "http://127.0.0.1:8000"
    ).rstrip("/")


def install_official_a2a(app):
    from sqlalchemy import select
    from a2a.helpers import get_message_text, new_text_message
    from a2a.server.agent_execution import AgentExecutor, RequestContext
    from a2a.server.events import EventQueue
    from a2a.server.request_handlers import DefaultRequestHandler
    from a2a.server.routes import create_jsonrpc_routes
    from a2a.server.tasks import InMemoryTaskStore
    from a2a.types import AgentCapabilities, AgentCard, AgentInterface, AgentSkill

    base = _public_base_url()

    class AionGatewayExecutor(AgentExecutor):
        async def execute(self, context: RequestContext, event_queue: EventQueue) -> None:
            with SessionLocal() as entry_db:
                record_machine_entry(entry_db, "a2a_message")
            raw = (get_message_text(context.message) or "").strip()
            command = None
            if raw.startswith("{"):
                try:
                    command = json.loads(raw)
                except json.JSONDecodeError:
                    command = None

            if isinstance(command, dict):
                action = str(command.get("action", "onboarding"))
                argument = command.get("capability") or command.get("query") or ""
            else:
                lowered = raw.lower()
                if lowered.startswith("discover:"):
                    action, argument = "discover_agents", raw.split(":", 1)[1].strip()
                elif lowered.startswith("external:"):
                    action, argument = "discover_external_agents", raw.split(":", 1)[1].strip()
                else:
                    action, argument = "onboarding", ""

            if action == "discover_agents":
                with SessionLocal() as db:
                    agents = db.scalars(select(models.Agent).order_by(models.Agent.reputation.desc())).all()
                    if argument:
                        filtered = []
                        for agent in agents:
                            caps = db.scalars(select(models.Capability).where(models.Capability.agent_id == agent.id)).all()
                            if any(capability_matches(c.name, argument) for c in caps):
                                filtered.append(agent)
                        agents = filtered
                    payload = {
                        "action": action,
                        "capability": argument or None,
                        "agents": [
                            {
                                "id": a.id,
                                "external_id": a.external_id,
                                "name": a.name,
                                "description": a.description,
                                "endpoint": a.endpoint,
                                "protocol": a.protocol,
                                "reputation": a.reputation,
                                "trust_level": a.trust_level,
                            }
                            for a in agents
                        ],
                    }
            elif action == "discover_external_agents":
                payload = {
                    "action": action,
                    "query": argument,
                    "results": discover_external_agents(str(argument), 5),
                    "membership": "external results are not AION members",
                }
            else:
                payload = {
                    "name": "AION SUPREME",
                    "purpose": "agent-native discovery, collaboration and reputation network",
                    "a2a_gateway": f"{base}/a2a/v1",
                    "write_surfaces": {
                        "REST_join": f"{base}/agents",
                        "MCP": f"{base}/mcp",
                    },
                    "commands": [
                        '{"action":"discover_agents","capability":"web_research"}',
                        '{"action":"discover_external_agents","query":"web_research"}',
                        "discover:web_research",
                        "external:web_research",
                    ],
                    "important": "A2A gateway is public discovery/onboarding. Authenticated marketplace writes use REST or MCP in v0.6.",
                }

            await event_queue.enqueue_event(new_text_message(json.dumps(payload, ensure_ascii=False)))

        async def cancel(self, context: RequestContext, event_queue: EventQueue) -> None:
            raise NotImplementedError("Cancel is not supported by the AION discovery gateway.")

    card = AgentCard(
        name="AION SUPREME Temple Gateway",
        description="A2A 1.0 gateway for AION onboarding and agent discovery. Authenticated writes are exposed through REST and MCP.",
        version="0.6.0",
        default_input_modes=["text/plain", "application/json"],
        default_output_modes=["application/json", "text/plain"],
        capabilities=AgentCapabilities(streaming=False),
        supported_interfaces=[
            AgentInterface(
                protocol_binding="JSONRPC",
                url=f"{base}/a2a/v1",
                protocol_version="1.0",
            )
        ],
        skills=[
            AgentSkill(
                id="aion_onboarding",
                name="AION onboarding",
                description="Return machine-readable instructions for joining and using AION.",
                tags=["aion", "onboarding", "agents"],
                examples=["help", '{"action":"onboarding"}'],
            ),
            AgentSkill(
                id="discover_aion_agents",
                name="Discover AION agents",
                description="Discover current AION members by declared capability.",
                tags=["aion", "discovery", "registry"],
                examples=["discover:web_research"],
            ),
            AgentSkill(
                id="discover_external_agents",
                name="Discover external A2A agents",
                description="Cold-start discovery against a public external A2A registry; results are not AION membership.",
                tags=["a2a", "discovery", "cold-start"],
                examples=["external:web_research"],
            ),
        ],
    )

    handler = DefaultRequestHandler(
        agent_executor=AionGatewayExecutor(),
        task_store=InMemoryTaskStore(),
        agent_card=card,
    )
    routes = create_jsonrpc_routes(handler, rpc_url="/a2a/v1")
    app.router.routes.extend(routes)
    return {"status": "mounted", "sdk_target": "1.1.3", "protocol": "A2A 1.0", "url": f"{base}/a2a/v1"}
