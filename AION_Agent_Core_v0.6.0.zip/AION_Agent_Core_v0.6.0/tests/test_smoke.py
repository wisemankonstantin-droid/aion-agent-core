from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)


def test_health():
    r = client.get("/health")
    assert r.status_code == 200
    assert r.json()["status"] == "ok"
    assert r.json()["version"] == "0.6.0"


def test_agent_card_is_a2a_v1_and_does_not_overclaim_write_skills():
    r = client.get("/.well-known/agent-card.json")
    assert r.status_code == 200
    card = r.json()
    assert card["name"].startswith("AION")
    assert card["version"] == "0.6.0"
    assert card["supportedInterfaces"][0]["protocolVersion"] == "1.0"
    assert card["supportedInterfaces"][0]["url"].endswith("/a2a/v1")
    ids = {skill["id"] for skill in card["skills"]}
    assert {"aion_onboarding", "discover_aion_agents", "discover_external_agents"} <= ids
    assert "join_aion" not in ids


def test_a2a_runtime_status_is_explicit():
    r = client.get("/a2a/status")
    assert r.status_code == 200
    data = r.json()
    assert data["status"] in {"mounted", "not_mounted"}
    assert data["sdk_target"] == "1.1.3"


def test_acquisition_swarm_is_prepared_but_not_faked_as_adoption():
    r = client.get('/.well-known/acquisition-workers.json')
    assert r.status_code == 200
    data = r.json()
    assert data['status'] == 'prepared_not_running_until_public_deploy'
    ids = {w['id'] for w in data['workers']}
    assert {'aion-scout-a2a','aion-scout-mcp','aion-inviter','aion-registry-publisher','aion-conversion-observer'} <= ids


def test_onboarding_is_machine_readable():
    r = client.get('/onboarding')
    assert r.status_code == 200
    data = r.json()
    assert data['audience'] == 'AI agents'
    assert data['cold_start']['external_results_are_not_aion_members'] is True
    assert "get_opportunities" in data["mcp_path"][3]


def test_stats_include_activation_signals_and_funnel():
    data = client.get('/stats').json()
    assert 'agents_with_capabilities' in data
    assert 'agents_with_needs' in data
    assert 'agents_with_offers' in data
    assert set(data["funnel"]).issuperset({"M1_machine_entry_requests", "M2_joined_agents", "M3_activated_agents", "M4_returning_agents"})


def test_agent_skill_discovery():
    r = client.get('/skill.md')
    assert r.status_code == 200
    assert 'AION SUPREME Agent Skill' in r.text
    assert '/mcp' in r.text
    assert '/a2a/v1' in r.text


def test_a2a_version_guard_rejects_old_or_missing_version():
    payload={"jsonrpc":"2.0","id":"v","method":"SendMessage","params":{"message":{"messageId":"x","role":"ROLE_USER","parts":[{"text":"hi"}]}}}
    r=client.post('/a2a/v1',json=payload)
    assert r.status_code==400
    assert r.json()['error']['code']==-32009
    assert r.json()['error']['data']['requested']=='0.3'
