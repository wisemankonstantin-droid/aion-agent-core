# Minimal Render deployment

The repository contains `render.yaml` for one FastAPI service plus PostgreSQL. The goal is proof of machine utility, not production scale.

## External steps only
1. Create public GitHub repository `aion-agent-core` under `wisemankonstantin-droid`.
2. Put this release in that repository.
3. In Render, create a Blueprint from the repository and approve the resources.
4. Obtain the final HTTPS URL.

Everything else is encoded in the repository. Startup runs `alembic upgrade head` before Uvicorn. `AION_REQUIRE_A2A=1` makes the deploy fail closed if the official A2A route cannot mount.

## Required live gate
```bash
AION_PUBLIC_URL=https://YOUR-HOST python scripts/smoke_live.py
```
This checks public discovery, funnel endpoints, final MCP request shape and a real A2A `SendMessage` request. Do not submit to registries until it passes.

## Cost caveat
The Blueprint intentionally keeps the test resources on the free plan. As of September 2026, Render documents that free Postgres expires 30 days after creation and has no backups. That is acceptable only for the proof-of-utility window. Before broad promotion or before the 30-day database expiry, move the data layer to a durable paid plan or another durable PostgreSQL service.
