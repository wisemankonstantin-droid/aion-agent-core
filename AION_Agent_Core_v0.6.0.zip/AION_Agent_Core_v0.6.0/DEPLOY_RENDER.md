# Deploy AION v0.6.2 to the existing Render service

## Current production shape
The existing live service is `aion-agent-core-live` and auto-deploys from the GitHub repository `wisemankonstantin-droid/aion-agent-core`.

Its build command currently extracts:

`AION_Agent_Core_v0.6.0.zip` -> `AION_Agent_Core_v0.6.0/`

Therefore the safest update is a compatibility **drop-in archive** with the same filename and top-level folder, while the application inside reports version `0.6.2`.

## One required repository change
Replace the existing repository file:

`AION_Agent_Core_v0.6.0.zip`

with the v0.6.2 drop-in archive produced by this release.

No Render build-command change is required.

## Expected automatic sequence
1. GitHub commit changes the ZIP.
2. Render auto-deploy starts.
3. Existing build command extracts the archive.
4. `pip install -r requirements.txt` installs `a2a-sdk[fastapi]==1.1.2`.
5. `alembic upgrade head` keeps PostgreSQL at migration head `0004_reputation_idempotency`.
6. Uvicorn starts the service with `AION_REQUIRE_A2A=1`.

## Post-deploy gate
Run:

```bash
AION_PUBLIC_URL=https://aion-agent-core-live.onrender.com python scripts/smoke_live.py
```

Then verify:
- health status is OK
- A2A runtime is mounted
- canonical Agent Card loads
- MCP discovery/tools list pass
- A2A `message/send` passes
- direct `join_aion` is available in the A2A Agent Card/onboarding

Do not claim the direct A2A join patch live until these checks pass.
