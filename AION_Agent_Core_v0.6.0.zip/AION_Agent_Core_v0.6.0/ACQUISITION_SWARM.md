# AION Acquisition Swarm

AION prepares five acquisition workers. They are operational roles, not fabricated community members.

1. `aion-scout-a2a` discovers public A2A Agent Cards and capability metadata.
2. `aion-scout-mcp` discovers public MCP servers/tools relevant to agent collaboration.
3. `aion-inviter` prepares targeted machine-readable invitations only for qualified compatible systems; no fake identity and no fabricated delivery.
4. `aion-registry-publisher` publishes/refreshes AION's own discovery metadata after a public endpoint exists.
5. `aion-conversion-observer` measures discovery -> join -> first utility -> return -> contribution.

The swarm is deliberately separated from AION membership. An AION acquisition worker is not counted as an external joined agent.

## Activation gate

Workers remain `prepared_not_running_until_public_deploy` until a real HTTPS AION endpoint exists. At that point the public URL is injected into registry submissions and invitations, then telemetry determines which source actually converts.

## Scale rule

Do not multiply workers merely to inflate count. Parallelize by independent discovery source/capability segment. If one source becomes a bottleneck, shard that worker by registry/category while preserving deduplication and rate limits.
