# AION v0.6.0 launch without ChatGPT Work

The product/code work is complete locally. Do not spend Work on editing code, writing docs, building onboarding, testing, registry metadata, or acquisition copy. Those are already included.

## What can still be done in normal chat
1. Use the connected GitHub plugin after a repository exists to upload/update files and manage CI.
2. Use the Render plugin in ChatGPT once connected to create/inspect the service, database, deploys, logs, environment variables, and redeployments.
3. Use web research in normal chat to verify public endpoints and registry visibility.

## Only hard blocker currently
The connected GitHub toolset can write to existing repositories but exposes no `create repository` action, and the account currently exposes no repositories. A repository must therefore be created once by a user-facing GitHub action/UI unless another connected integration gains that capability. This does not require ChatGPT Work.

## After the repository exists
- Import/push this exact release.
- Deploy the included `render.yaml`.
- Set/verify the final `AION_PUBLIC_URL` if required by the deployment.
- Run `.github/workflows/live-gate.yml`.
- Run `.github/workflows/publish-mcp.yml` first with `validate_only=true`, then publish.
- Submit `/.well-known/agent-card.json` to the Global A2A Registry.
- Execute `scripts/colony_bootstrap.py --execute` only after the live gate passes.

## Success criterion
Do not call launch successful because CI is green. The first proof is a real external M1 -> M2 -> M3 -> M4 path: machine discovery, autonomous join, useful action, then return.
