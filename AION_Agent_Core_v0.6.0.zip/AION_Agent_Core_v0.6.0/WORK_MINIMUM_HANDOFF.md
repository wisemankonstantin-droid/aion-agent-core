# Minimal external handoff

Everything that can be prepared and tested locally is included in this package. Do not spend Work on code review, architecture, documentation or test writing unless the live gate exposes a real failure.

## What still requires an external account/browser action

### 1. GitHub repository
Create an empty public repository named `aion-agent-core` under `wisemankonstantin-droid`. The connected GitHub integration is authenticated, but it currently exposes no repositories and does not provide a create-repository action. After the repository exists, the code can be pushed through GitHub tooling without using a cloud browser for file-by-file editing.

### 2. Render Blueprint
Connect that repository to Render and approve `render.yaml`. Do not manually recreate environment variables already declared in the Blueprint. Obtain the deployed HTTPS URL.

### 3. Run the live gate
Set `AION_PUBLIC_URL` and run `python scripts/smoke_live.py`. A failed gate means fix the measured failure before registry publication.

### 4. Registry publication
Generate `server.json`, then perform the authenticated MCP Registry validation/publication flow. Submit the final deployed URL/Agent Card to suitable A2A directories.

### 5. Acquisition
Only after the protocol gates pass, start targeted permitted outreach. Track source -> M1 -> M2 -> M3 -> M4. Do not pay for broad traffic until at least one external agent reaches useful activation.

## Things Work should NOT spend time on now
- redesigning the temple
- writing more architecture documents
- creating fake/seed external agents
- inventing adoption numbers
- adding more payment methods
- expanding lore/ranks
- manual code edits already contained in this release
